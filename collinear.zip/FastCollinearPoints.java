import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class FastCollinearPoints {

    private static final ArrayList<LineSegment> LINE_SEGMENTS = new ArrayList<>();
    private static final HashMap<Double, List<Point>> SLOPE_TO_END_POINTS = new HashMap<>();

    /* Find all line segments containing 4 or more points */



    public FastCollinearPoints(Point[] pts) {
        checkNull(pts);
        for (Point pt : pts) {
            checkNull(pt);
        }

        Point[] orderedPoints = pts.clone();
        Arrays.sort(orderedPoints);
        dCheck(orderedPoints);

        for (int i = 0; i < orderedPoints.length; i++) {
            Arrays.sort(orderedPoints, i, orderedPoints.length);
            Point origin = orderedPoints[i];
            Arrays.sort(orderedPoints, i + 1, orderedPoints.length, origin.slopeOrder());

            int count = 0;
            double prevSlope = Double.NaN;
            Point prevPoint = origin;
            for (int j = i + 1; j < orderedPoints.length; j++) {
                Point point = orderedPoints[j];
                double slope = origin.slopeTo(point);

                if (Double.compare(slope, prevSlope) == 0) {
                    count += 1;
                } else {
                    if (count >= 3) {
                        checkAndAdd(origin, prevPoint, prevSlope);
                    }

                    prevSlope = slope;
                    count = 1;
                }
                prevPoint = point;
            }

            if (count >= 3) {
                checkAndAdd(origin, prevPoint, prevSlope);
            }
        }
    }

    private void checkAndAdd(Point start, Point end, double slope) {
        List<Point> ptExist = SLOPE_TO_END_POINTS.get(slope);

        if (ptExist == null) {
            ptExist = new ArrayList<>(); // empty the array
            ptExist.add(end);

            SLOPE_TO_END_POINTS.put(slope, ptExist);

            LINE_SEGMENTS.add(new LineSegment(start, end));
        } else {
            if (!ptExist.contains(end)) {
                // add if point is non existent
                ptExist.add(end);

                LINE_SEGMENTS.add(new LineSegment(start, end));
            }
        }
    }

    private void dCheck(Point[] orderedPointValues) {
        for (int i = 0; i < orderedPointValues.length - 1; i++) {
            if (orderedPointValues[i].compareTo(orderedPointValues[i + 1]) == 0) {
                throw new IllegalArgumentException();
            }
        }
    }

    /**
     * the number of line segments
     */
    public int numberOfSegments() {
        return LINE_SEGMENTS.size();
    }

    /**
     * the line segments
     */
    public LineSegment[] segments() {
        return LINE_SEGMENTS.toArray(new LineSegment[]{});
    }

    private void checkNull(Object obj) {
        /* Check Weather an Object Value is null */
        if (obj == null) {
            throw new IllegalArgumentException();
        }
    }
    public static void main(String[] args) {
        /* Read input Data From File */

        In inputData = new In(args[0]);
        int n = inputData.readInt();
        Point[] pts = new Point[n];

        for (int i = 0; i < n; i++) {
            int x = inputData.readInt();
            int y = inputData.readInt();
            pts[i] = new Point(x, y);
        }

        /* Plot Data Points */
        // draw the points
        StdDraw.enableDoubleBuffering();
        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        for (Point p : pts) {
            p.draw();
        }
        StdDraw.show();

        /*  display and draw the line segments */
        FastCollinearPoints collinear = new FastCollinearPoints(pts);
        for (LineSegment segment : collinear.segments()) {
            StdOut.println(segment);
            segment.draw();
        }
        StdDraw.show();
    }
}
